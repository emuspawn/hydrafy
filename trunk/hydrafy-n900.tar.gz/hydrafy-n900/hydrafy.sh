#!/bin/bash
cd /home/user/MyDocs/pwnphone/hydrafy
bash ./hydrafy_launch.sh
